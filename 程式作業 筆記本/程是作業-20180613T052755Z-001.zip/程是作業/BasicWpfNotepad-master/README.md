# Basic WPF Notepad
This is a basic WPF notepad demo. It shows how to Save/Open files. 

## Assignment
Please **fork** this repository and improve it.